package de.datev.wowlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WowlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
